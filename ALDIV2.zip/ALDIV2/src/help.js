const help = (prefix) => {
	return `Menu ${namabot}
╭────────────────────────
├❖ *${prefix}buggc*
├❖ *${prefix}bughole*
├❖ *${prefix}sendbug*
├❖ *${prefix}bugimg*
├❖ *${prefix}bugtroli*
├❖ *${prefix}clone*
├❖ *${prefix}leave*
├❖ *${prefix}welcome*
├❖ *${prefix}antilink*
├❖ *${prefix}hacked*
├❖ *${prefix}kick*
├❖ *${prefix}add*
├❖ *${prefix}demote*
├❖ *${prefix}promote*
├❖ *${prefix}bc*
├❖ *${prefix}bugkatalog*
├❖ *${prefix}bugloc*
├❖ *${prefix}bugrow*
├❖ *${prefix}buglink*
├❖ *${prefix}bugbutton*
├❖ *${prefix}bug [ jumlah ]*
├❖ *${prefix}bugpc2 [ jumlah ]*
├❖ *${prefix}bugtroli2 [ jumlah ]*
├❖ *${prefix}bugtroli3*
├❖ *${prefix}bugpc*
├❖ *${prefix}bugcombine*
├❖ *${prefix}bugtroli*
├❖ *${prefix}buglokasi*
├❖ *${prefix}bughole*
├❖ *${prefix}clearall*
├❖ *${prefix}linkgroup*
├❖ *${prefix}infobot*
╰────────────────────────
*TQ TO*
*MHANKBARBAR*
*BOT INDO (PRII) (Pengembang)*
*Alan Botz (kang recode)*
*Xenn Botz*
*TQ TO MY PARTNER*`
}

exports.help = help
